﻿#ifndef __AN_INCLUDES_H__
#define __AN_INCLUDES_H__
#include "CWePlayerCfg.h"

extern CWePlayerCfg* gPlayCfgData;

int GetScaledSize(int size);

#endif
