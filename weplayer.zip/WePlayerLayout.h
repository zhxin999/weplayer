﻿#ifndef WEPLAYER_LAYOUT_H
#define WEPLAYER_LAYOUT_H
#include <QWidget>
#include <QList>
#include <QListWidget>
#include <QTimer>
#include <QList>
#include <QJsonObject>
#include <QJsonDocument>
#include <QByteArray>


#endif
