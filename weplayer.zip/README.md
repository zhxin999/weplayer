# 播放器介绍

WePLayer是一款简单，干净，支持UDP播放控制的视频播放器。
因为源码文件来自多个项目，稍显凌乱:)

#### 编译
 - Windows: Qt5.9.4 + vs2015 x86
 - UOS: 系统自带Qt5 + 系统自带FFMPEG

#### 依赖库
 - FFMPEG
 - Qt5

#### 支持系统

 - Windows ( 可执行程序下载: [百度云盘](https://pan.baidu.com/s/1uPq64MZPryPyPn0wgpr4Lg), 提取码：zhxn)
 - UOS    (统信应用商店搜索WePlayer, 或者是百度云盘下载com.ucosoft.weplayer_xxx_amd64.deb)
 - Ubuntu  (下载)
 - Jetson (曾经测试过，请自行编译测试)
 - 理论上所有能支持Qt及FFMPEG的系统都可以运行

#### UDP通信接口

稍后

#### 其他
 - Bin目录包含Windows系统下的动态库
